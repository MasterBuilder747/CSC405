/*
Homework 8
Name: Joseph Audras
Professor: Dr. Reinhart
Class: CSC 405-1
Date due: 4-14-20
*/

package Homework.HW8TriangleDrawGUI;

public abstract class SceneGraphBase {

    protected double[][] vertices;

    public void setScene(double[][] newscene) {
        vertices = newscene;
    }

    public double getScene () {
        return 0.0;
    }

    //
    //public abstract void render (int framebuffer[][], int gray) {

    //cube:

}
