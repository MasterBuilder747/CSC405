/*
Homework 8
Name: Joseph Audras
Professor: Dr. Reinhart
Class: CSC 405-1
Date due: 4-14-20
*/

package Homework.HW8TriangleDrawGUI;

public class HandleSplit {

    //testing on split
    public static void main(String[] args) {
        String s = "";
        String[] s1 = s.split(",\\s*");
        System.out.println(s1[0]);
        System.out.println(s1.length);
    }

}
