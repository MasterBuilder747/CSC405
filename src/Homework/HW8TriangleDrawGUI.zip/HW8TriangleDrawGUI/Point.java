/*
Homework 7
Name: Joseph Audras
Professor: Dr. Reinhart
Class: CSC 405-1
Date due: 3-26-20
*/

package Homework.HW8TriangleDrawGUI;

public class Point {
    double x;
    double y;

    private Point() {

    }

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }
}
