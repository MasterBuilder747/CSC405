/*
Homework 7
Name: Joseph Audras
Professor: Dr. Reinhart
Class: CSC 405-1
Date due: 3-26-20
*/

package Homework.HW7TriangleFill;

public abstract class SceneGraphBase {

    protected double[][] vertices;

    public void setScene(double[][] newscene) {
        vertices = newscene;
    }

    public double getScene () {
        return 0.0;
    }

    //
    //public abstract void render (int framebuffer[][], int gray) {

    //cube:

}
