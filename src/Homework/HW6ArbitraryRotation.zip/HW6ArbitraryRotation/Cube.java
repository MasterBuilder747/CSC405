/*
Homework 6
Name: Joseph Audras
Professor: Dr. Reinhart
Class: CSC 405-1
Date due: 3-19-20
*/

package Homework.HW6ArbitraryRotation;

public class Cube extends SceneGraph {

    //maybe will do this, idk how extends works yet


}
